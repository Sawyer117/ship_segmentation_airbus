import os
import numpy as np  # linear algebra
import pandas as pd  # data processing, CSV file I/O (e.g. pd.read_csv)
import cv2
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from keras import losses
from keras.models import Model
from keras.layers import *
from keras.optimizers import Adam
from keras.regularizers import l2
from keras.preprocessing.image import ImageDataGenerator
import keras.backend as K
from keras.callbacks import LearningRateScheduler, ModelCheckpoint

# ======= initial parameters =================
# this is for cancelling the visualization when I submit to cedar
illustrate_results = True
# ======= initialization settings ============
#  database address
IMAGE_LIB = './Janet_velar_k/images_cropped/'
MASK_LIB = './Janet_velar_k/Masks_cropped/'

#  image size --> must be in square shape shuangyue
IMG_HEIGHT, IMG_WIDTH = 128, 128

#  read images and masks from folder
all_images = [x for x in sorted(os.listdir(IMAGE_LIB)) if x[-4:] == '.jpg']
all_masks = [x for x in sorted(os.listdir(MASK_LIB)) if x[-4:] == '.jpg']

# images first read, resize to square and normalized to [0, 1] then flatten as a vector
#  make a vector X [data size, image x, image y]
x_data = np.empty((len(all_images), IMG_HEIGHT, IMG_WIDTH), dtype='float32')
for i, name in enumerate(all_images):
    im = cv2.imread(IMAGE_LIB + name, cv2.IMREAD_GRAYSCALE)
    im = cv2.resize(im, dsize=(IMG_WIDTH, IMG_HEIGHT), interpolation=cv2.INTER_AREA)
    im = (im - np.min(im)) / (np.max(im) - np.min(im))
    x_data[i] = im
#  make a vector Y [data size, mask x, mask y]
y_data = np.empty((len(all_masks), IMG_HEIGHT, IMG_WIDTH), dtype='float32')
for i, name in enumerate(all_masks):
    im = cv2.imread(MASK_LIB + name, cv2.IMREAD_GRAYSCALE)
    im = cv2.resize(im, dsize=(IMG_WIDTH, IMG_HEIGHT), interpolation=cv2.INTER_AREA)
    im[im >= 200] = 255
    im = (im - np.min(im)) / (np.max(im) - np.min(im))
    y_data[i] = im

if illustrate_results:
    fig, ax = plt.subplots(1, 2, figsize=(8, 4))
    ax[0].imshow(x_data[np.random.randint(len(all_images))], cmap='gray')
    ax[1].imshow(y_data[np.random.randint(len(all_masks))], cmap='gray')
    plt.show()

# newaxis is similar to none. it add a new dimension as I understand
# separate data into test and train using sklearn then show 12 of them
x_data = x_data[:, :, :, np.newaxis]
y_data = y_data[:, :, :, np.newaxis]
x_train, x_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.2, random_state=42)

# I add this part to make sure about training and testing data names
if illustrate_results:
    fig, ax = plt.subplots(1, 4, figsize=(12, 6))
    ax[0].imshow(x_train[0, :, :, 0], cmap='gray')
    ax[1].imshow(y_train[0, :, :, 0], cmap='gray')
    ax[2].imshow(x_test[0, :, :, 0], cmap='gray')
    ax[3].imshow(y_test[0, :, :, 0], cmap='gray')
    plt.show()


# Dice coefficient
def dice_coef(y_true, y_pred):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f * y_pred_f)
    #return (2. * intersection + K.epsilon()) / (K.sum(y_true_f) + K.sum(y_pred_f) + K.epsilon())
    return (2. * intersection + 1) / (K.sum(y_true_f) + K.sum(y_pred_f) + 1)
def dice_coef_loss(y_true, y_pred):
##    y_true_f = K.flatten(y_true)
##    y_pred_f = K.flatten(y_pred)
##    intersection = K.sum(y_true_f * y_pred_f)
##    return 1-(2. * intersection + K.epsilon()) / (K.sum(y_true_f) + K.sum(y_pred_f) + K.epsilon())
      return -dice_coef(y_true,y_pred)

    
def mean_squared_error(y_true, y_pred):
    return K.mean(K.square(y_pred - y_true), axis=-1)

# UNET model
# FCN model

input_layer = Input(shape=x_train.shape[1:])

x = Conv2D(64, (3, 3), activation='relu', padding='same', name='block1_conv1', )(input_layer)
x = Conv2D(64, (3, 3), activation='relu', padding='same', name='block1_conv2', )(x)
x = MaxPooling2D((2, 2), strides=(2, 2), name='block1_pool')(x)

# Block 2
x = Conv2D(128, (3, 3), activation='relu', padding='same', name='block2_conv1',)(x)
x = Conv2D(128, (3, 3), activation='relu', padding='same', name='block2_conv2',)(x)
x = MaxPooling2D((2, 2), strides=(2, 2), name='block2_pool')(x)

# Block 3
x = Conv2D(256, (3, 3), activation='relu', padding='same', name='block3_conv1', )(x)
x = Conv2D(256, (3, 3), activation='relu', padding='same', name='block3_conv2', )(x)
x = Conv2D(256, (3, 3), activation='relu', padding='same', name='block3_conv3', )(x)
x = MaxPooling2D((2, 2), strides=(2, 2), name='block3_pool')(x)

# Block 4
x = Conv2D(512, (3, 3), activation='relu', padding='same', name='block4_conv1', )(x)
x = Conv2D(512, (3, 3), activation='relu', padding='same', name='block4_conv2', )(x)
x = Conv2D(512, (3, 3), activation='relu', padding='same', name='block4_conv3', )(x)
x = MaxPooling2D((2, 2), strides=(2, 2), name='block4_pool')(x)

# Block 5
x = Conv2D(512, (3, 3), activation='relu', padding='same', name='block5_conv1', )(x)
x = Conv2D(512, (3, 3), activation='relu', padding='same', name='block5_conv2', )(x)
x = Conv2D(512, (3, 3), activation='relu', padding='same', name='block5_conv3', )(x)
x = MaxPooling2D((2, 2), strides=(2, 2), name='block5_pool')(x)

# Convolutional layers transfered from fully-connected layers
x = Conv2D(4096, (7, 7), activation='relu', padding='same', name='fc1', )(x)
x = Dropout(0.5)(x)
x = Conv2D(4096, (1, 1), activation='relu', padding='same', name='fc2', )(x)
x = Dropout(0.5)(x)
#classifying layer
x = Conv2D((1, 1), kernel_initializer='he_normal', activation='linear', padding='valid', strides=(1, 1), kernel_size=(3, 3))(x)

x = BilinearUpSampling2D(size=(32, 32))(x)

model = Model(input_layer, x)


#model = Model(input_layer, output_layer)

#  ?
SEED = 42

def my_generator(x_train, y_train, batch_size):
    data_generator = ImageDataGenerator(
        width_shift_range=0.1,
        height_shift_range=0.1,
        rotation_range=10,
        zoom_range=0.1).flow(x_train, x_train, batch_size, seed=SEED)
    mask_generator = ImageDataGenerator(
        width_shift_range=0.1,
        height_shift_range=0.1,
        rotation_range=10,
        zoom_range=0.1).flow(y_train, y_train, batch_size, seed=SEED)
    while True:
        x_batch, _ = data_generator.next()
        y_batch, _ = mask_generator.next()
        yield x_batch, y_batch


image_batch, mask_batch = next(my_generator(x_train, y_train, 8))
fix, ax = plt.subplots(8, 2, figsize=(8, 20))
for i in range(8):
    ax[i, 0].imshow(image_batch[i, :, :, 0])
    ax[i, 1].imshow(mask_batch[i, :, :, 0])
plt.show()

#model.compile(optimizer=Adam(2e-3), loss='binary_crossentropy', metrics=[dice_coef])#was dice_coef
model.compile(optimizer=Adam(2e-6), loss='binary_crossentropy', metrics=[dice_coef])#was dice_coef
# model.compile(optimizer=Adam(2e-4), loss=losses.mean_squared_error, metrics=['accuracy'])
# model.compile(optimizer=Adam(2e-4), loss='mse', metrics=[mean_squared_error])
weight_saver = ModelCheckpoint('lung.h5', monitor='val_dice_coef', save_best_only=False, save_weights_only=True)
# weight_saver = ModelCheckpoint('lung.h5', monitor='val_loss', save_best_only=True, save_weights_only=True)
# weight_saver = ModelCheckpoint('lung.h5', monitor='val_mean_squared_error', save_best_only=True, save_weights_only=True)
#annealer = LearningRateScheduler(lambda x: 1e-3 * 0.8 ** x)#was 1e-4

hist = model.fit_generator(my_generator(x_train, y_train, 8),
                           steps_per_epoch=5,
                           validation_data=(x_test, y_test),
                           epochs=200, verbose=1,
                           callbacks=[weight_saver])


#model.fit(x_train, y_train, steps_per_epoch=10, epochs=1, verbose=1,validation_split=0.2, shuffle=True, callbacks=[weight_saver])
#model.load_weights('lung.h5')
#plt.imshow(model.predict(x_train[0].reshape(1, IMG_HEIGHT, IMG_WIDTH, 1))[0, :, :, 0], cmap='gray')
#plt.show()

y_hat = model.predict(x_test)
fig, ax = plt.subplots(1, 3, figsize=(12, 6))
for i in range(4):
    ax[0].imshow(x_test[i, :, :, 0], cmap='gray')
    ax[1].imshow(y_test[i, :, :, 0])
    ax[2].imshow(y_hat[i, :, :, 0])
plt.show()

model.save('my_model.h5')
#model.save('lung.h5')
