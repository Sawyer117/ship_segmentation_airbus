import numpy as np
import cv2
import keras
from keras.models import Model
from keras.layers import *
import numpy as np
import time
from matplotlib import pyplot as plt


#im = np.empty((1, 256, 256, 1))
#y_hat = np.empty((1, 256, 256, 1))
IMG_HEIGHT, IMG_WIDTH = 256, 256
merge1 = np.zeros((512, 512))
font = cv2.FONT_HERSHEY_SIMPLEX
i=1    
#cap = cv2.VideoCapture('./video_for_process/Janet_Alveolar_l.avi')
#cap = cv2.VideoCapture('./video_for_process/Janet_Alveolar_r.avi')
#cap = cv2.VideoCapture('./video_for_process/Janet_Alveolar_t.avi')
#cap = cv2.VideoCapture('./video_for_process/Janet_Bilabial_p.avi')
cap = cv2.VideoCapture('./video_for_process/Janet_velar_k.avi')
  

#----------------------------old model-------------------------------#
# =============================================================================
# input_layer = Input(shape=(128, 128, 1))
# c1 = Conv2D(filters=16, kernel_size=(3, 3), activation='relu')(input_layer)
# mc12 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c1)
# 
# # second layer
# c2 = Conv2D(filters=32, kernel_size=(3, 3), activation='relu')(mc12)
# mc22 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c2)
# 
# # third layer
# c3 = Conv2D(filters=64, kernel_size=(3, 3), activation='relu')(mc22)
# mc32 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c3)
# 
# # fourth layer
# c4 = Conv2D(filters=128, kernel_size=(3, 3), activation='relu')(mc32)
# mc42 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c4)
# 
# # fifth layer
# c5 = Conv2D(filters=256, kernel_size=(3, 3), activation='relu')(mc42)
# # five to four
# uc54 = concatenate([UpSampling2D(size=(2, 2))(c5), Cropping2D(cropping=((2, 2), (2, 2)))(c4)], axis=-1)
# uc54c2 = Conv2D(filters=128, kernel_size=(3, 3), activation='relu')(uc54)
# 
# # four to three
# uc43 = concatenate([UpSampling2D(size=(2, 2))(uc54c2), Cropping2D(cropping=((8, 8), (8, 8)))(c3)], axis=-1)
# uc43c2 = Conv2D(filters=64, kernel_size=(3, 3), activation='relu')(uc43)
# 
# 
# # three to two
# uc32 = concatenate([UpSampling2D(size=(2, 2))(uc43c2), Cropping2D(cropping=((20, 21), (20, 21)))(c2)], axis=-1)
# uc32c2 = Conv2D(filters=32, kernel_size=(3, 3), activation='relu')(uc32)
# 
# 
# # two to one
# uc21 = concatenate([UpSampling2D(size=(2, 2))(uc32c2), Cropping2D(cropping=((45, 45), (45, 45)))(c1)], axis=-1)
# uc21c2 = Conv2D(filters=16, kernel_size=(3, 3), activation='relu')(uc21)
# uc21c3=Dropout(0.1, noise_shape=None, seed=None)(uc21c2)
# output_layer = Conv2D(filters=1, kernel_size=(1, 1), activation='sigmoid')(uc21c3)
# 
# 
# model = Model(input_layer, output_layer)
# =============================================================================

#----------------------------new model-------------------------------#
input_layer = Input(shape=x_train.shape[1:])
# first layer
c1 = Conv2D(filters=32, kernel_size=(3, 3), activation='relu', padding='same')(input_layer)
c12 = Conv2D(filters=32, kernel_size=(3, 3), activation='relu', padding='same')(c1)
mc12 = MaxPool2D(pool_size=(2, 2), strides=(2, 2), padding='same')(c12)

# second layer
c2 = Conv2D(filters=64, kernel_size=(3, 3), activation='relu', padding='same')(mc12)
c22 = Conv2D(filters=64, kernel_size=(3, 3), activation='relu', padding='same')(c2)
mc22 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c22)

# third layer
c3 = Conv2D(filters=128, kernel_size=(3, 3), activation='relu', padding='same')(mc22)
c32 = Conv2D(filters=128, kernel_size=(3, 3), activation='relu', padding='same')(c3)
mc32 = MaxPool2D(pool_size=(2, 2), strides=(2, 2), padding='same')(c32)

# fourth layer
c4 = Conv2D(filters=256, kernel_size=(3, 3), activation='relu', padding='same')(mc32)
c42 = Conv2D(filters=256, kernel_size=(3, 3), activation='relu', padding='same')(c4)
mc42 = MaxPool2D(pool_size=(2, 2), strides=(2, 2), padding='same')(c42)

# fifth layer
c5 = Conv2D(filters=512, kernel_size=(3, 3), activation='relu', padding='same')(mc42)
c52 = Conv2D(filters=512, kernel_size=(3, 3), activation='relu', padding='same')(c5)

# five to four
uc54 = concatenate([UpSampling2D(size=(2, 2))(c52), c42], axis=-1)
uc54c1 = Conv2D(filters=256, kernel_size=(3, 3), activation='relu', padding='same')(uc54)
uc54c2 = Conv2D(filters=256, kernel_size=(3, 3), activation='relu', padding='same')(uc54c1)

# four to three
uc43 = concatenate([UpSampling2D(size=(2, 2))(uc54c2), c32], axis=-1)
uc43c1 = Conv2D(filters=128, kernel_size=(3, 3), activation='relu', padding='same')(uc43)
uc43c2 = Conv2D(filters=128, kernel_size=(3, 3), activation='relu', padding='same')(uc43c1)

# three to two
uc32 = concatenate([UpSampling2D(size=(2, 2))(uc43c2), c22], axis=-1)
uc32c1 = Conv2D(filters=64, kernel_size=(3, 3), activation='relu', padding='same')(uc32)
uc32c2 = Conv2D(filters=64, kernel_size=(3, 3), activation='relu', padding='same')(uc32c1)

# two to onw
uc21 = concatenate([UpSampling2D(size=(2, 2))(uc32c2), c12], axis=-1)
uc21c1 = Conv2D(filters=32, kernel_size=(3, 3), activation='relu', padding='same')(uc21)
uc21c2 = Conv2D(filters=32, kernel_size=(3, 3), activation='relu', padding='same')(uc21c1)
output_layer = Conv2D(filters=1, kernel_size=(1, 1), activation='sigmoid', padding='same')(uc21c2)

model = Model(input_layer, output_layer)

#----------------------------------------------------------------------------
model.load_weights('my_model.h5') #my_model.h5
framecount=0
pastime=0
while(cap.isOpened()):
    framecount=framecount+1
    start = time.clock()
    ret, frame = cap.read()
    if frame is None:
        break;
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    #frame = (im - np.min(frame)) / (np.max(frame) - np.min(frame))
    im = cv2.resize(frame, dsize=(IMG_WIDTH, IMG_HEIGHT), interpolation=cv2.INTER_AREA)
    im = (im - np.min(im)) / (np.max(im) - np.min(im))
    im=im[None,:,:,None]
    y_hat = model.predict(im)
    y_hat = cv2.resize(y_hat[0, :, :, 0], dsize=(256, 256), interpolation=cv2.INTER_AREA)
    showimage = cv2.resize(im[0, :, :, 0], dsize=(256, 256), interpolation=cv2.INTER_AREA)
    merge1[127:383,0:256]=showimage
    merge1[127:383,256:512]=y_hat
    cv2.putText(merge1,'original      prediction',(80,100), font, 1,(255,255,255),2,cv2.LINE_AA)
    #cv2.putText(merge1,'CG++ Ultrasound Imaging Group',(240,470), font, 0.5,(255,255,255),2,cv2.LINE_AA)
    #cv2.putText(merge1,'University of Ottawa',(240,490), font, 0.5,(255,255,255),2,cv2.LINE_AA)
    cv2.imshow('merge',merge1)
    #cv2.imwrite('./GeneratedPerformanceImage/', merge1)
    cv2.imwrite('./GeneratedPerformanceImage/'+str(i)+'.png', 255*merge1)
    i=i+1
    print(time.clock() - start)
    pastime=pastime+(time.clock() - start)
    if cv2.waitKey(20) & 0xFF == ord('q'):
        break
pastime=pastime+(time.clock() - start)
avgtime=pastime/framecount
print('total time is'+str(pastime)+'\n total frame is '+str(framecount)+'\navgtime is '+str(avgtime)+'\n avg fps is '+str(1/avgtime))
cap.release()
cv2.destroyAllWindows()
