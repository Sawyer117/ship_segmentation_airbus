import os
import numpy as np  # linear algebra
import pandas as pd  # data processing, CSV file I/O (e.g. pd.read_csv)
import cv2
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from keras.models import Model
from keras.layers import *
import keras
from keras.optimizers import Adam
from keras.regularizers import l2
from keras.preprocessing.image import ImageDataGenerator
import keras.backend as K
from keras.callbacks import LearningRateScheduler, ModelCheckpoint

def dice_coef(y_true, y_pred):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f * y_pred_f)
    return (2. * intersection + K.epsilon()) / (K.sum(y_true_f) + K.sum(y_pred_f) + K.epsilon())

#
IMAGE_LIB = './Janet_velar_k/images_cropped/'
MASK_LIB = './Janet_velar_k/Masks_cropped/'

IMG_HEIGHT, IMG_WIDTH = 256, 256
SEED = 42

all_images = [x for x in sorted(os.listdir(IMAGE_LIB)) if x[-4:] == '.jpg']
all_images2 = [x for x in sorted(os.listdir(MASK_LIB)) if x[-4:] == '.jpg']

x_data = np.empty((len(all_images), IMG_HEIGHT, IMG_WIDTH), dtype='float32')
for i, name in enumerate(all_images):
    im = cv2.imread(IMAGE_LIB + name, cv2.IMREAD_GRAYSCALE).astype("int16").astype('float32')
    # im = cv2.imread(IMAGE_LIB + name, cv2.IMREAD_GRAYSCALE)
    im = cv2.resize(im, dsize=(IMG_WIDTH, IMG_HEIGHT), interpolation=cv2.INTER_LANCZOS4)
    im = (im - np.min(im)) / (np.max(im) - np.min(im))
    x_data[i] = im

y_data = np.empty((len(all_images), IMG_HEIGHT, IMG_WIDTH), dtype='float32')
for i, name in enumerate(all_images2):
    im = cv2.imread(MASK_LIB + name, cv2.IMREAD_GRAYSCALE).astype('float32') / 255.
    im = cv2.resize(im, dsize=(IMG_WIDTH, IMG_HEIGHT), interpolation=cv2.INTER_NEAREST)
    y_data[i] = im

# fig, ax = plt.subplots(1, 2, figsize=(8, 4))
# ax[0].imshow(x_data[0], cmap='gray')
# ax[1].imshow(y_data[0], cmap='gray')
# plt.show()

# newaxis is similar to none. it add a new dimension as I understand
x_data = x_data[:, :, :, np.newaxis]
y_data = y_data[:, :, :, np.newaxis]
x_train, x_val, y_train, y_val = train_test_split(x_data, y_data, test_size=0.2)
#print("desired shape is "+str(x_train.shape[1:]))
#
# plt.imshow(y_data[0, :, :, 0], cmap='gray')
# plt.show()
###################old model########################################
##input_layer = Input(shape=x_train.shape[1:])
##c1 = Conv2D(filters=8, kernel_size=(3, 3), activation='relu', padding='same')(input_layer)
##l = MaxPool2D(strides=(2, 2))(c1)
##c2 = Conv2D(filters=16, kernel_size=(3, 3), activation='relu', padding='same')(l)
##l = MaxPool2D(strides=(2, 2))(c2)
##c3 = Conv2D(filters=32, kernel_size=(3, 3), activation='relu', padding='same')(l)
##l = MaxPool2D(strides=(2, 2))(c3)
##c4 = Conv2D(filters=64, kernel_size=(1, 1), activation='relu', padding='same')(l)
##l = concatenate([UpSampling2D(size=(2, 2))(c4), c3], axis=-1)
##l = Conv2D(filters=32, kernel_size=(2, 2), activation='relu', padding='same')(l)
##l = concatenate([UpSampling2D(size=(2, 2))(l), c2], axis=-1)
##l = Conv2D(filters=24, kernel_size=(2, 2), activation='relu', padding='same')(l)
##l = concatenate([UpSampling2D(size=(2, 2))(l), c1], axis=-1)
##l = Conv2D(filters=16, kernel_size=(2, 2), activation='relu', padding='same')(l)
##l = Conv2D(filters=64, kernel_size=(1, 1), activation='relu')(l)
##l = Dropout(0.5)(l)
##output_layer = Conv2D(filters=1, kernel_size=(1, 1), activation='sigmoid')(l)
############################new model################################
input_layer = Input(shape=x_train.shape[1:])
# first layer
c1 = Conv2D(filters=32, kernel_size=(3, 3), activation='relu', padding='same')(input_layer)
c12 = Conv2D(filters=32, kernel_size=(3, 3), activation='relu', padding='same')(c1)
mc12 = MaxPool2D(pool_size=(2, 2), strides=(2, 2), padding='same')(c12)

# second layer
c2 = Conv2D(filters=64, kernel_size=(3, 3), activation='relu', padding='same')(mc12)
c22 = Conv2D(filters=64, kernel_size=(3, 3), activation='relu', padding='same')(c2)
mc22 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c22)

# third layer
c3 = Conv2D(filters=128, kernel_size=(3, 3), activation='relu', padding='same')(mc22)
c32 = Conv2D(filters=128, kernel_size=(3, 3), activation='relu', padding='same')(c3)
mc32 = MaxPool2D(pool_size=(2, 2), strides=(2, 2), padding='same')(c32)

# fourth layer
c4 = Conv2D(filters=256, kernel_size=(3, 3), activation='relu', padding='same')(mc32)
c42 = Conv2D(filters=256, kernel_size=(3, 3), activation='relu', padding='same')(c4)
mc42 = MaxPool2D(pool_size=(2, 2), strides=(2, 2), padding='same')(c42)

# fifth layer
c5 = Conv2D(filters=512, kernel_size=(3, 3), activation='relu', padding='same')(mc42)
c52 = Conv2D(filters=512, kernel_size=(3, 3), activation='relu', padding='same')(c5)

# five to four
uc54 = concatenate([UpSampling2D(size=(2, 2))(c52), c42], axis=-1)
uc54c1 = Conv2D(filters=256, kernel_size=(3, 3), activation='relu', padding='same')(uc54)
uc54c2 = Conv2D(filters=256, kernel_size=(3, 3), activation='relu', padding='same')(uc54c1)

# four to three
uc43 = concatenate([UpSampling2D(size=(2, 2))(uc54c2), c32], axis=-1)
uc43c1 = Conv2D(filters=128, kernel_size=(3, 3), activation='relu', padding='same')(uc43)
uc43c2 = Conv2D(filters=128, kernel_size=(3, 3), activation='relu', padding='same')(uc43c1)

# three to two
uc32 = concatenate([UpSampling2D(size=(2, 2))(uc43c2), c22], axis=-1)
uc32c1 = Conv2D(filters=64, kernel_size=(3, 3), activation='relu', padding='same')(uc32)
uc32c2 = Conv2D(filters=64, kernel_size=(3, 3), activation='relu', padding='same')(uc32c1)

# two to onw
uc21 = concatenate([UpSampling2D(size=(2, 2))(uc32c2), c12], axis=-1)
uc21c1 = Conv2D(filters=32, kernel_size=(3, 3), activation='relu', padding='same')(uc21)
uc21c2 = Conv2D(filters=32, kernel_size=(3, 3), activation='relu', padding='same')(uc21c1)
output_layer = Conv2D(filters=1, kernel_size=(1, 1), activation='sigmoid', padding='same')(uc21c2)

model = Model(input_layer, output_layer)
model.load_weights('lung.h5') #my_model.h5
#model.load_weights('lungEXP#3.h5')

y_hat = model.predict(x_val[None,1])
#print("in prediction,the feeded shape is "+str(x_val.shape))
fig, ax = plt.subplots(1, 3, figsize=(12, 6))
ax[0].imshow(x_val[1, :, :, 0], cmap='gray')
ax[1].imshow(y_val[1, :, :, 0])
ax[2].imshow(y_hat[0, :, :, 0])
#ax[2].imshow(y_hat)
plt.show()
