import cv2
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg

img = cv2.imread("./Janet_velar_k/Masks_cropped/Janet_Alveolar_l_Mask_43.jpg");
image = mpimg.imread("./Janet_velar_k/Masks_cropped/Janet_Alveolar_l_Mask_43.jpg")
ret,thresh1 = cv2.threshold(image,240,1,cv2.THRESH_BINARY)
#cv2.imshow('origin',img)
#cv2.imshow('thresh',thresh1)
plt.imshow(thresh1)
plt.show()
