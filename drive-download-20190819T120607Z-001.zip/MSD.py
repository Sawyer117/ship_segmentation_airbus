# -*- coding: utf-8 -*-
"""
Created on Thu Feb 22 18:56:36 2018

@author: Wen

"""
import numpy as np


def MSD(u,v):   #find the mean sum of distance of vector u&v,u is truth,v is prediction

    la=u.shape[0]  #number of points in vec u
    lb=v.shape[0]  #number of points in vec v
    #print('u length is '+str(la)+' and v length is '+str(lb))
    uvdis=np.zeros([1,la])
    vudis=np.zeros([1,lb])
    for i in range(1,la):
      uvdis[0,i-1]=np.amin(np.sqrt(np.sum((v-u[i-1]) ** 2,axis=1)))
      #uvdis[0,i]=min(np.sqrt(np.sum((v-u[i]) ** 2,axis=1)))
    uvdis=np.sum(uvdis)

    for i in range(1,lb):
      vudis[0,i-1]=np.amin(np.sqrt(np.sum((u-v[i-1]) ** 2,axis=1)))
      #vudis[0,i]=min(np.sqrt(np.sum((u-v[i]) ** 2,axis=1)))
    vudis=np.sum(vudis)
    msd=1/(la+lb)*(uvdis+vudis)
    return msd
