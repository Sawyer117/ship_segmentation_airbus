import numpy as np
import cv2

image = cv2.imread('./Janet_velar_k/Masks_cropped/Janet_Alveolar_l_Mask_1.jpg')
print(image.shape)




