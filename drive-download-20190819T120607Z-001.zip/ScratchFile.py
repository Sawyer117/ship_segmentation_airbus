# -*- coding: utf-8 -*-
"""
Created on Tue Apr 17 08:56:27 2018

@author: Wen
"""
import cv2
import os
from natsort import natsorted


i=1
image_folder = './v2Data-Hamed/images_cropped/'
#image_folder = './v2Data-Hamed/masks_cropped/'
  
images = [img for img in os.listdir(image_folder) if img.endswith(".bmp")]
images = natsorted(images)
IMG_WIDTH=256
IMG_HEIGHT=256
# =============================================================================
# IMG_WIDTH=128
# IMG_HEIGHT=128
# im = cv2.resize(images[0], dsize=(IMG_WIDTH, IMG_HEIGHT), interpolation=cv2.INTER_NEAREST)   
# im=im[0:100,:]
# 
# cv2.imshow('1',images[0])
# cv2.imshow('2',im)
# img = cv2.resize(im, dsize=(IMG_WIDTH, IMG_HEIGHT), interpolation=cv2.INTER_NEAREST) 
# cv2.imshow('3',img)
# =============================================================================
for image in images:
    image1 = cv2.imread('./v2Data-Hamed/images_cropped/'+image,0)
    #im = cv2.resize(image1, dsize=(IMG_WIDTH, IMG_HEIGHT), interpolation=cv2.INTER_NEAREST)   
    im=image1[0:int(0.8*image1.shape[0]),:]
    
    #cv2.imshow('1',image1)
    #cv2.imshow('2',im)
    img = cv2.resize(im, dsize=(IMG_WIDTH, IMG_HEIGHT), interpolation=cv2.INTER_NEAREST) 
    #cv2.imshow('3',img)
    cv2.imwrite('./v2Data-Hamed/new_images_cropped/'+str(i)+'.png', img)
    i=i+1