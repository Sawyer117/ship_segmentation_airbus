import os
import numpy as np  # linear algebra
import pandas as pd  # data processing, CSV file I/O (e.g. pd.read_csv)
import cv2
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from keras.models import Model
from keras.layers import *
import keras
from keras.optimizers import Adam
from keras.regularizers import l2
from keras.preprocessing.image import ImageDataGenerator
import keras.backend as K
from keras.callbacks import LearningRateScheduler, ModelCheckpoint
import time
from skimage.morphology import skeletonize,remove_small_objects
from skimage.measure import label, regionprops
import scipy.misc as sp
import scipy.interpolate
from MSD import MSD
from corlorize import corlorize

def dice_coef(y_true, y_pred):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f * y_pred_f)
    return (2. * intersection + K.epsilon()) / (K.sum(y_true_f) + K.sum(y_pred_f) + K.epsilon())

#
#IMAGE_LIB = './Janet_velar_k/images_cropped/'testImg
IMAGE_LIB = './testImg/images_cropped/'
MASK_LIB = './testImg/Masks_cropped/'

IMG_HEIGHT, IMG_WIDTH = 128, 128


all_images = [x for x in sorted(os.listdir(IMAGE_LIB)) if x[-4:] == '.jpg']
all_images2 = [x for x in sorted(os.listdir(MASK_LIB)) if x[-4:] == '.jpg']

x_data = np.empty((len(all_images), IMG_HEIGHT, IMG_WIDTH), dtype='float32')
for i, name in enumerate(all_images):
    im = cv2.imread(IMAGE_LIB + name, cv2.IMREAD_GRAYSCALE).astype("int16").astype('float32')
    # im = cv2.imread(IMAGE_LIB + name, cv2.IMREAD_GRAYSCALE)
    im = cv2.resize(im, dsize=(IMG_WIDTH, IMG_HEIGHT), interpolation=cv2.INTER_LANCZOS4)
    im = (im - np.min(im)) / (np.max(im) - np.min(im))
    x_data[i] = im

y_data = np.empty((len(all_images), IMG_HEIGHT, IMG_WIDTH), dtype='float32')
for i, name in enumerate(all_images2):
    im = cv2.imread(MASK_LIB + name, cv2.IMREAD_GRAYSCALE).astype('float32') / 255.
    im = cv2.resize(im, dsize=(IMG_WIDTH, IMG_HEIGHT), interpolation=cv2.INTER_NEAREST)
    y_data[i] = im

# fig, ax = plt.subplots(1, 2, figsize=(8, 4))
# ax[0].imshow(x_data[0], cmap='gray')
# ax[1].imshow(y_data[0], cmap='gray')
# plt.show()

# newaxis is similar to none. it add a new dimension as I understand
x_data = x_data[:, :, :, np.newaxis]
y_data = y_data[:, :, :, np.newaxis]
x_train, x_val, y_train, y_val = train_test_split(x_data, y_data, test_size=0.2)
print("desired shape is "+str(x_train.shape[1:]))
#

############################new model################################
#----------------------------current model-------------------------------#
input_layer = Input(shape=x_train.shape[1:])
c1 = Conv2D(filters=16, kernel_size=(3, 3), activation='relu')(input_layer)
mc12 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c1)

# second layer
c2 = Conv2D(filters=32, kernel_size=(3, 3), activation='relu')(mc12)
mc22 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c2)

# third layer
c3 = Conv2D(filters=64, kernel_size=(3, 3), activation='relu')(mc22)
mc32 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c3)

# fourth layer
c4 = Conv2D(filters=128, kernel_size=(3, 3), activation='relu')(mc32)
mc42 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c4)

# fifth layer
c5 = Conv2D(filters=256, kernel_size=(3, 3), activation='relu')(mc42)
# five to four
uc54 = concatenate([UpSampling2D(size=(2, 2))(c5), Cropping2D(cropping=((2, 2), (2, 2)))(c4)], axis=-1)
uc54c2 = Conv2D(filters=128, kernel_size=(3, 3), activation='relu')(uc54)

# four to three
uc43 = concatenate([UpSampling2D(size=(2, 2))(uc54c2), Cropping2D(cropping=((8, 8), (8, 8)))(c3)], axis=-1)
uc43c2 = Conv2D(filters=64, kernel_size=(3, 3), activation='relu')(uc43)


# three to two
uc32 = concatenate([UpSampling2D(size=(2, 2))(uc43c2), Cropping2D(cropping=((20, 21), (20, 21)))(c2)], axis=-1)
uc32c2 = Conv2D(filters=32, kernel_size=(3, 3), activation='relu')(uc32)


# two to one
uc21 = concatenate([UpSampling2D(size=(2, 2))(uc32c2), Cropping2D(cropping=((45, 45), (45, 45)))(c1)], axis=-1)
uc21c2 = Conv2D(filters=16, kernel_size=(3, 3), activation='relu')(uc21)
uc21c3=Dropout(0.1, noise_shape=None, seed=None)(uc21c2)
output_layer = Conv2D(filters=1, kernel_size=(1, 1), activation='sigmoid')(uc21c3)


model = Model(input_layer, output_layer)

#model = Model(input_layer, output_layer)
model.load_weights('my_model.h5') #my_model.h5
#model.load_weights('lungEXP#3.h5')

y_hat = model.predict(x_val[0:100,:,:,:])
print("in prediction,the feeded shape is "+str(x_val.shape))


def findline(image):
    [m,n]=image.shape
    linespace=np.zeros((1,n))
    sumPix=image.sum(axis=0)

    for j in range(0,n-1):
        average=0
        for i in range(0,m-1):
          sumPix1=sumPix[j]
          average=average+(i+1)*image[i,j]/sumPix1
          linespace[0,j]=round(average)
    lineImage=np.zeros((m,n))
    for p in range(0,n-1):
        row=linespace[0,p]
        print(row)
        lineImage[int(row-1),int(p)]=1
    return lineImage


avgMSD1=np.zeros([y_hat.shape[0],1])
for i in range(50):
    area1=[]
    area2=[]
    fig, ax = plt.subplots(2, 3, figsize=(12, 6))
    ax[0,0].imshow(x_val[i, :, :, 0], cmap='gray')
    ax[0,0].set_title('original image')
    ax[0,0].get_xaxis().set_visible(False)
    ax[0,0].get_yaxis().set_visible(False)
    cv2.imwrite('./figCache/original.png', 255*x_val[i, :, :, 0])
    y_test = y_val[i, :, :, 0]
    #y_test[y_test<=2*10^-3]=0
    ret,y_test = cv2.threshold(y_val[i, :, :, 0],0.1,1,cv2.THRESH_BINARY)
    y_test = skeletonize(y_test)*1
    #ax[0,1].imshow(y_test)
    ax[0,1].imshow(y_val[i, :, :, 0])
    ax[0,1].set_title('manual label')
    ax[0,1].get_xaxis().set_visible(False)
    ax[0,1].get_yaxis().set_visible(False)
    cv2.imwrite('./figCache/manual label.png', 255*y_val[i, :, :, 0])
    ax[0,2].imshow(y_hat[i, :, :, 0])
    ax[0,2].set_title('predicted mask')
    ax[0,2].get_xaxis().set_visible(False)
    ax[0,2].get_yaxis().set_visible(False)
    pred111=cv2.resize(y_hat[i, :, :, 0], dsize=(128, 128), interpolation=cv2.INTER_CUBIC)
    cv2.imwrite('./figCache/prediction.png', 255*pred111)
    ret,thresh1 = cv2.threshold(y_hat[i, :, :, 0],0.4,1,cv2.THRESH_BINARY)
    #ret, labels = cv2.connectedComponents(np.int_(thresh1))
    
    label_image = label(thresh1)
    region=regionprops(label_image)
    for ii in range(len(region)):
       area=region[ii].area
       area1.append(area)
    largestarea=np.max(area1)
    b = remove_small_objects(label_image,largestarea-1)
    
    ax[1,0].imshow(b)
    ax[1,0].set_title('binarized mask')
    ax[1,0].get_xaxis().set_visible(False)
    ax[1,0].get_yaxis().set_visible(False)
    bmask=cv2.resize(np.float32(b), dsize=(128, 128), interpolation=cv2.INTER_CUBIC)
    cv2.imwrite('./figCache/binarized mask.png', 255*bmask)

    start = time.clock()
    lineImage=cv2.resize(y_hat[i, :, :, 0], dsize=(128, 128), interpolation=cv2.INTER_CUBIC)
    #lineImage=cv2.resize(np.float32(b), dsize=(128, 128), interpolation=cv2.INTER_CUBIC)
    ret,lineImage=cv2.threshold(lineImage,0.12,1,cv2.THRESH_BINARY)
    lineImage = skeletonize(lineImage)*1
    #--------------------------------------------------------
    label_line = label(lineImage)
    lineregion = regionprops(label_line)
    for pp in range(len(lineregion)):
       area=lineregion[pp].area
       area2.append(area)
    largestarea1=np.max(area2)
    bb = remove_small_objects(label_line,largestarea1)
   #ret,bb=cv2.threshold(bb,0.1,1,cv2.THRESH_BINARY)
    #--------------------------------------------------------   
    #ax[1,1].imshow(lineImage)
    ax[1,1].imshow(bb) #recover this
    ax[1,1].set_title('skeletonized') #extracted Line
    ax[1,1].get_xaxis().set_visible(False)
    ax[1,1].get_yaxis().set_visible(False)
    cv2.imwrite('./figCache/skeletonized.png', 255*bb)

    location1=np.asarray(np.where(y_test==1)).T
    location2=np.asarray(np.where(np.int_(np.bool_(bb))==1)).T
   # location2=np.asarray(np.where(bb==1)).T
    msd=MSD(location1,location2)
    print('msd is '+str(msd))
    #print(time.clock() - start)
    
    superimpose=corlorize(x_val[i, :, :, 0]*255,bb)
    #cv2.imwrite('original'+str(i)+'.bmp',x_val[i, :, :, 0]*255)
    #cv2.imwrite('manual label'+str(i)+'.bmp',y_val[i, :, :, 0]*255)
    #cv2.imwrite('predicted mask'+str(i)+'.bmp',cv2.resize(y_hat[i, :, :, 0]*255, dsize=(128, 128), interpolation=cv2.INTER_CUBIC))  
    #cv2.imwrite('superimpose'+str(i)+'.bmp',superimpose)
    ax[1,2].imshow(superimpose/255,cmap=None)
    ax[1,2].set_title('superimposed image')
    ax[1,2].get_xaxis().set_visible(False)
    ax[1,2].get_yaxis().set_visible(False)
    cv2.imwrite('./figCache/superimpose.png', superimpose)
    plt.show()
    avgMSD1[i,0]=msd
avgMSD=np.sum(avgMSD1)/50
print('avgmsd is '+str(avgMSD))
# =============================================================================
# avgMSD=np.zeros([y_hat.shape[0],1])
# for i in range(y_hat.shape[0]):
#     y_test = y_val[i, :, :, 0]
#     ret,y_test = cv2.threshold(y_val[i, :, :, 0],0.2,1,cv2.THRESH_BINARY)
#     y_test = skeletonize(y_test)*1
#     lineImage=cv2.resize(y_hat[i, :, :, 0], dsize=(128, 128), interpolation=cv2.INTER_CUBIC)
#     ret,lineImage=cv2.threshold(lineImage,0.12,1,cv2.THRESH_BINARY)
#     lineImage = skeletonize(lineImage)*1
#     location1=np.asarray(np.where(y_test==1)).T
#     location2=np.asarray(np.where(lineImage==1)).T
#     msd=MSD(location1,location2)
#     avgMSD[i,0]=msd
#     
# avgMSD=np.sum(avgMSD)/y_hat.shape[0]
# =============================================================================
