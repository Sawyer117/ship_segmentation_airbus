import os
import numpy as np  # linear algebra
import pandas as pd  # data processing, CSV file I/O (e.g. pd.read_csv)
import cv2
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from keras import losses
from keras.models import Model
from keras.layers import *
from keras.optimizers import Adam
from keras import optimizers
from keras.regularizers import l2
from keras.preprocessing.image import ImageDataGenerator
import keras.backend as K
from keras.callbacks import LearningRateScheduler, ModelCheckpoint

# ======= initial parameters =================
# this is for cancelling the visualization when I submit to cedar
illustrate_results = True
# ======= initialization settings ============
#  database address
IMAGE_LIB = './Janet_velar_k/images_cropped/'
MASK_LIB = './Janet_velar_k/Masks_cropped/'

#  image size --> must be in square shape
IMG_HEIGHT, IMG_WIDTH = 128, 128
MSK_HEIGHT, MSK_WIDTH = 34, 34

#  read images and masks from folder
all_images = [x for x in sorted(os.listdir(IMAGE_LIB)) if x[-4:] == '.jpg']
all_masks = [x for x in sorted(os.listdir(MASK_LIB)) if x[-4:] == '.jpg']

# images first read, resize to square and normalized to [0, 1] then flatten as a vector
#  make a vector X [data size, image x, image y] (This is for trainning data)
x_data = np.empty((len(all_images), IMG_HEIGHT, IMG_WIDTH), dtype='float32')
for i, name in enumerate(all_images):
    im = cv2.imread(IMAGE_LIB + name, cv2.IMREAD_GRAYSCALE)
    im = cv2.resize(im, dsize=(IMG_WIDTH, IMG_HEIGHT), interpolation=cv2.INTER_AREA)
    im = (im - np.min(im)) / (np.max(im) - np.min(im))
    x_data[i] = im
#  make a vector Y [data size, mask x, mask y] (This is for testing data)
y_data = np.empty((len(all_masks), MSK_HEIGHT, MSK_WIDTH), dtype='float32')
for i, name in enumerate(all_masks):
    im = cv2.imread(MASK_LIB + name, cv2.IMREAD_GRAYSCALE)/255
    im = cv2.resize(im, dsize=(MSK_WIDTH, MSK_HEIGHT), interpolation=cv2.INTER_AREA)
    im[im >= 0.78] = 1
    im = (im - np.min(im)) / (np.max(im) - np.min(im))
    #y_data[i] = np.float32(np.bool_(im))
    y_data[i] = im

if illustrate_results:
    fig, ax = plt.subplots(1, 2, figsize=(8, 4))
    ax[0].imshow(x_data[np.random.randint(len(all_images))], cmap='gray')
    ax[1].imshow(y_data[np.random.randint(len(all_masks))], cmap='gray')
    plt.show()

# newaxis is similar to none. it add a new dimension as I understand
# separate data into test and train using sklearn then show 12 of them
x_data = x_data[:, :, :, np.newaxis]
y_data = y_data[:, :, :, np.newaxis]
x_train, x_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.2, random_state=42)

# I add this part to make sure about training and testing data names
if illustrate_results:
    fig, ax = plt.subplots(1, 4, figsize=(12, 6))
    ax[0].imshow(x_train[0, :, :, 0], cmap='gray')
    ax[1].imshow(y_train[0, :, :, 0], cmap='gray')
    ax[2].imshow(x_test[0, :, :, 0], cmap='gray')
    ax[3].imshow(y_test[0, :, :, 0], cmap='gray')
    plt.show()


# Dice coefficient
def dice_coef(y_true, y_pred,smooth=1):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f * y_pred_f)
    #return (2. * intersection + K.epsilon()) / (K.sum(y_true_f) + K.sum(y_pred_f) + K.epsilon())
    #y_true_f = K.flatten(y_true)
    #y_pred_f = K.flatten(y_pred)
    #intersection = K.dot(y_true, K.transpose(y_pred))
    #union = K.dot(y_true,K.transpose(y_true))+K.dot(y_pred,K.transpose(y_pred))
    return (2. * intersection + K.epsilon()) / (K.sum(y_true_f) + K.sum(y_pred_f) + K.epsilon())
    #return (2. * intersection + 1) / (K.sum(y_true_f) + K.sum(y_pred_f) + 1) #K.epsilon()
def dice_coef_loss(y_true, y_pred):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f * y_pred_f)
    return 1-(2. * intersection + 1) / ((K.sum(y_true_f) + K.sum(y_pred_f) + 1))
    #return -dice_coef(y_true,y_pred) #K.epsilon()

    
def mean_squared_error(y_true, y_pred):
    return K.mean(K.square(y_pred - y_true), axis=-1)

# UNET model

input_layer = Input(shape=x_train.shape[1:])
c1 = Conv2D(filters=16, kernel_size=(3, 3), activation='relu')(input_layer)
mc12 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c1)

# second layer
c2 = Conv2D(filters=32, kernel_size=(3, 3), activation='relu')(mc12)
mc22 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c2)

# third layer
c3 = Conv2D(filters=64, kernel_size=(3, 3), activation='relu')(mc22)
mc32 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c3)

# fourth layer
c4 = Conv2D(filters=128, kernel_size=(3, 3), activation='relu')(mc32)
mc42 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c4)

# fifth layer
c5 = Conv2D(filters=256, kernel_size=(3, 3), activation='relu')(mc42)
#c5=Dropout(0.1, noise_shape=None, seed=None)(c5)
# five to four
uc54 = concatenate([UpSampling2D(size=(2, 2))(c5), Cropping2D(cropping=((2, 2), (2, 2)))(c4)], axis=-1)
uc54c2 = Conv2D(filters=128, kernel_size=(3, 3), activation='relu')(uc54)

# four to three
uc43 = concatenate([UpSampling2D(size=(2, 2))(uc54c2), Cropping2D(cropping=((8, 8), (8, 8)))(c3)], axis=-1)
uc43c2 = Conv2D(filters=64, kernel_size=(3, 3), activation='relu')(uc43)
#uc43c2=Dropout(0.1, noise_shape=None, seed=None)(uc43c2)

# three to two
uc32 = concatenate([UpSampling2D(size=(2, 2))(uc43c2), Cropping2D(cropping=((20, 21), (20, 21)))(c2)], axis=-1)
uc32c2 = Conv2D(filters=32, kernel_size=(3, 3), activation='relu')(uc32)


# two to one
uc21 = concatenate([UpSampling2D(size=(2, 2))(uc32c2), Cropping2D(cropping=((45, 45), (45, 45)))(c1)], axis=-1)
uc21c2 = Conv2D(filters=16, kernel_size=(3, 3), activation='relu')(uc21)
#uc21c2=Dropout(0.1, noise_shape=None, seed=None)(uc21c2)
output_layer = Conv2D(filters=1, kernel_size=(1, 1), activation='sigmoid')(uc21c2)


model = Model(input_layer, output_layer)


##fix, ax = plt.subplots(8, 2, figsize=(8, 20))
##for i in range(8):
##    ax[i, 0].imshow(image_batch[i, :, :, 0])
##    ax[i, 1].imshow(mask_batch[i, :, :, 0])
##plt.show()
#adam=Adam(lr=0.001, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.08, amsgrad=False)
adam=Adam(lr=0.0001, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.005,amsgrad=False)
#model.compile(optimizer=Adam(2e-3), loss='binary_crossentropy', metrics=[dice_coef])#was dice_coef
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=[dice_coef,'mae','accuracy'])#was dice_coef
#model.compile(optimizer='adam', loss='mse', metrics=[dice_coef,'mae','acc'])#was dice_coef
#model.fit(x_train, y_train, epochs=1, batch_size=10,validation_split=0.2, shuffle=True, callbacks=[weight_saver])
history=model.fit(x_data, y_data, validation_split=0.2,epochs=100, batch_size=64)
#model.load_weights('lung.h5')

# summarize history for accuracy
plt.plot(history.history['dice_coef'])
plt.plot(history.history['val_dice_coef'])
plt.title('model dice_coef')
plt.ylabel('dice_coef')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()
# summarize history for loss
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

plt.plot(history.history['mean_absolute_error'])
plt.plot(history.history['val_mean_absolute_error'])
plt.title('model mae')
plt.ylabel('mean_absolute_error')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

plt.plot(history.history['acc'])
plt.plot(history.history['val_acc'])
plt.title('model acc')
plt.ylabel('acc')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

y_hat = model.predict(x_test)
fig, ax = plt.subplots(1, 3, figsize=(12, 6))
for i in range(4):
    ax[0].imshow(x_test[i, :, :, 0], cmap='gray')
    ax[1].imshow(y_test[i, :, :, 0])
    ax[2].imshow(y_hat[i, :, :, 0])
plt.show()

model.save('my_model.h5')
#model.save('lung.h5')
