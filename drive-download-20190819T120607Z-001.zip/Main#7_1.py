import os
import numpy as np  # linear algebra
import pandas as pd  # data processing, CSV file I/O (e.g. pd.read_csv)
import cv2
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from keras import losses
from keras.models import Model
from keras.layers import *
from keras.optimizers import Adam
from keras.regularizers import l2
from keras.preprocessing.image import ImageDataGenerator
import keras.backend as K
from keras.callbacks import LearningRateScheduler, ModelCheckpoint

# ======= initial parameters =================
# this is for cancelling the visualization when I submit to cedar
illustrate_results = True
# ======= initialization settings ============
#  database address
IMAGE_LIB = './new data/images_cropped/'
MASK_LIB = './new data/Masks_cropped/'

#  image size --> must be in square shape shuangyue
IMG_HEIGHT, IMG_WIDTH = 128, 128

#  read images and masks from folder
all_images = [x for x in sorted(os.listdir(IMAGE_LIB)) if x[-4:] == '.jpg']
all_masks = [x for x in sorted(os.listdir(MASK_LIB)) if x[-4:] == '.jpg']

# images first read, resize to square and normalized to [0, 1] then flatten as a vector
#  make a vector X [data size, image x, image y]
x_data = np.empty((len(all_images), IMG_HEIGHT, IMG_WIDTH), dtype='float32')
for i, name in enumerate(all_images):
    im = cv2.imread(IMAGE_LIB + name, cv2.IMREAD_GRAYSCALE)
    im = cv2.resize(im, dsize=(IMG_WIDTH, IMG_HEIGHT), interpolation=cv2.INTER_AREA)
    im = (im - np.min(im)) / (np.max(im) - np.min(im))
    x_data[i] = im
#  make a vector Y [data size, mask x, mask y]
y_data = np.empty((len(all_masks), IMG_HEIGHT, IMG_WIDTH), dtype='float32')
for i, name in enumerate(all_masks):
    im = cv2.imread(MASK_LIB + name, cv2.IMREAD_GRAYSCALE)
    im = cv2.resize(im, dsize=(IMG_WIDTH, IMG_HEIGHT), interpolation=cv2.INTER_AREA)
    im[im >= 200] = 255
    im = (im - np.min(im)) / (np.max(im) - np.min(im))
    y_data[i] = im

if illustrate_results:
    fig, ax = plt.subplots(1, 2, figsize=(8, 4))
    ax[0].imshow(x_data[np.random.randint(len(all_images))], cmap='gray')
    ax[1].imshow(y_data[np.random.randint(len(all_masks))], cmap='gray')
    plt.show()

# newaxis is similar to none. it add a new dimension as I understand
# separate data into test and train using sklearn then show 12 of them
x_data = x_data[:, :, :, np.newaxis]
y_data = y_data[:, :, :, np.newaxis]
x_train, x_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.2, random_state=42)

# I add this part to make sure about training and testing data names
if illustrate_results:
    fig, ax = plt.subplots(1, 4, figsize=(12, 6))
    ax[0].imshow(x_train[0, :, :, 0], cmap='gray')
    ax[1].imshow(y_train[0, :, :, 0], cmap='gray')
    ax[2].imshow(x_test[0, :, :, 0], cmap='gray')
    ax[3].imshow(y_test[0, :, :, 0], cmap='gray')
    plt.show()


# Dice coefficient
def dice_coef(y_true, y_pred):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f * y_pred_f)
    #return (2. * intersection + K.epsilon()) / (K.sum(y_true_f) + K.sum(y_pred_f) + K.epsilon())
    return (2. * intersection + 1) / (K.sum(y_true_f) + K.sum(y_pred_f) + 1)
def dice_coef_loss(y_true, y_pred):
##    y_true_f = K.flatten(y_true)
##    y_pred_f = K.flatten(y_pred)
##    intersection = K.sum(y_true_f * y_pred_f)
##    return 1-(2. * intersection + K.epsilon()) / (K.sum(y_true_f) + K.sum(y_pred_f) + K.epsilon())
      return -dice_coef(y_true,y_pred)

    
def mean_squared_error(y_true, y_pred):
    return K.mean(K.square(y_pred - y_true), axis=-1)

# UNET model
# FCN model
#input_layer = Input(shape=(128, 128, 1))
filtersize=16
input_layer = Input(shape=x_train.shape[1:])
c1 = Conv2D(filters=filtersize, kernel_size=(3, 3), activation='relu')(input_layer)
mc12 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c1)

# second layer
c2 = Conv2D(filters=filtersize*2, kernel_size=(3, 3), activation='relu')(mc12)
mc22 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c2)

# third layer
c3 = Conv2D(filters=filtersize*4, kernel_size=(3, 3), activation='relu')(mc22)
mc32 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c3)

# fourth layer
c4 = Conv2D(filters=filtersize*8, kernel_size=(3, 3), activation='relu')(mc32)
mc42 = MaxPool2D(pool_size=(2, 2), strides=(2, 2))(c4)

# fifth layer
c5 = Conv2D(filters=filtersize*16, kernel_size=(3, 3), activation='relu')(mc42)
# five to four
uc54 = concatenate([UpSampling2D(size=(2, 2))(c5), Cropping2D(cropping=((2, 2), (2, 2)))(c4)], axis=-1)
uc54c2 = Conv2D(filters=filtersize*8, kernel_size=(3, 3), activation='relu')(uc54)

# four to three
uc43 = concatenate([UpSampling2D(size=(2, 2))(uc54c2), Cropping2D(cropping=((8, 8), (8, 8)))(c3)], axis=-1)
uc43c2 = Conv2D(filters=filtersize*4, kernel_size=(3, 3), activation='relu')(uc43)

# three to two
uc32 = concatenate([UpSampling2D(size=(2, 2))(uc43c2), Cropping2D(cropping=((20, 21), (20, 21)))(c2)], axis=-1)
uc32c2 = Conv2D(filters=filtersize*2, kernel_size=(3, 3), activation='relu')(uc32)

# two to one
uc21 = concatenate([UpSampling2D(size=(2, 2))(uc32c2), Cropping2D(cropping=((45, 45), (45, 45)))(c1)], axis=-1)
uc21c2 = Conv2D(filters=filtersize, kernel_size=(3, 3), activation='relu')(uc21)
output_layer = Conv2D(filters=1, kernel_size=(1, 1), activation='sigmoid')(uc21c2)


model = Model(input_layer, output_layer)


#model = Model(input_layer, output_layer)

#  ?
SEED = 42

def my_generator(x_train, y_train, batch_size):
    data_generator = ImageDataGenerator(
        width_shift_range=0.1,
        height_shift_range=0.1,
        rotation_range=10,
        zoom_range=0.1).flow(x_train, x_train, batch_size, seed=SEED)
    mask_generator = ImageDataGenerator(
        width_shift_range=0.1,
        height_shift_range=0.1,
        rotation_range=10,
        zoom_range=0.1).flow(y_train, y_train, batch_size, seed=SEED)
    while True:
        x_batch, _ = data_generator.next()
        y_batch, _ = mask_generator.next()
        yield x_batch, y_batch


image_batch, mask_batch = next(my_generator(x_train, y_train, 8))
fix, ax = plt.subplots(8, 2, figsize=(8, 20))
for i in range(8):
    ax[i, 0].imshow(image_batch[i, :, :, 0])
    ax[i, 1].imshow(mask_batch[i, :, :, 0])
plt.show()

#model.compile(optimizer=Adam(2e-3), loss='binary_crossentropy', metrics=[dice_coef])#was dice_coef
model.compile(optimizer=Adam(2e-6), loss='binary_crossentropy', metrics=[dice_coef])#was dice_coef
# model.compile(optimizer=Adam(2e-4), loss=losses.mean_squared_error, metrics=['accuracy'])
# model.compile(optimizer=Adam(2e-4), loss='mse', metrics=[mean_squared_error])
weight_saver = ModelCheckpoint('lung.h5', monitor='val_dice_coef', save_best_only=False, save_weights_only=True)
# weight_saver = ModelCheckpoint('lung.h5', monitor='val_loss', save_best_only=True, save_weights_only=True)
# weight_saver = ModelCheckpoint('lung.h5', monitor='val_mean_squared_error', save_best_only=True, save_weights_only=True)
#annealer = LearningRateScheduler(lambda x: 1e-3 * 0.8 ** x)#was 1e-4

hist = model.fit_generator(my_generator(x_train, y_train, 8),
                           steps_per_epoch=5,
                           validation_data=(x_test, y_test),
                           epochs=200, verbose=1,
                           callbacks=[weight_saver])


#model.fit(x_train, y_train, steps_per_epoch=10, epochs=1, verbose=1,validation_split=0.2, shuffle=True, callbacks=[weight_saver])
#model.load_weights('lung.h5')
#plt.imshow(model.predict(x_train[0].reshape(1, IMG_HEIGHT, IMG_WIDTH, 1))[0, :, :, 0], cmap='gray')
#plt.show()

y_hat = model.predict(x_test)
fig, ax = plt.subplots(1, 3, figsize=(12, 6))
for i in range(4):
    ax[0].imshow(x_test[i, :, :, 0], cmap='gray')
    ax[1].imshow(y_test[i, :, :, 0])
    ax[2].imshow(y_hat[i, :, :, 0])
plt.show()

model.save('my_model.h5')
#model.save('lung.h5')
